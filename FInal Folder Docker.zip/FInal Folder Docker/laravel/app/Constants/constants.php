<?php
define('APPLICATION_NAME','Trail Test');
define('API_VERSION','v1');
define('PLAZA_MILES', 0.5);
define('LIMIT', 10);
?>
