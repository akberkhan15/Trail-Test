<template>
<div>
<h1>Home</h1>
<router-link to='/login'>Login</router-link>
</div>
</template>