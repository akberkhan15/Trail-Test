<?php

return [
    "edit_plaza_success" => "plaza edited successfully.",
    "delete_plaza_success" => "plaza deleted successfully.",
    "get_nearest_plaza_success"=> "nearest plaza successfully.",
    "error_invalid_plaza_id" => "Plaza id is invalid.",
    "plaza_add_success" => "plaza added successfully."
];
